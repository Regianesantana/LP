package DAO;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import DTO.Livro;
import java.util.ArrayList;
import java.util.List;

public class LivroDAO {
    
    private GerenciadorBD bd;
    
    public LivroDAO() {
        bd = new GerenciadorBD();
    }
    
    public void cadastrar(Livro livro) throws SQLException {
        try (Connection conexao = bd.conectar(); 
             PreparedStatement comando = conexao.prepareStatement(
             "INSERT INTO livro (titulo, autor, editora, Num_paginas, Ano_publicacao, ISBN) VALUES (?, ?, ?, ?, ?, ?)")
            ) 
        {
            comando.setString(1, livro.getTitulo());
            comando.setString(2, livro.getAutor());
            comando.setString(3, livro.getEditora());
            comando.setInt(4, livro.getNum_paginas());
            comando.setInt(5, livro.getAno_publicacao());
            comando.setString(6, livro.getISBN());
            comando.executeUpdate();
        }
    }
    
    
}
