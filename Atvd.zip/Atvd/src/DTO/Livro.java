package DTO;


public class Livro {
    private int id;
    private String titulo;
    private String autor;
    private String editora;
    private int Num_paginas;
    private int Ano_publicacao;
    private String ISBN;
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
    
     public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }
    
     public String getEditora() {
        return editora;
    }

    public void setEditora(String editora) {
        this.editora = editora;
        
        
    }
    
    public int getNum_paginas() {
        return Num_paginas;
    }

    public void setNum_paginas(int Num_paginas) {
        this.Num_paginas = Num_paginas;
    }
    
    public int getAno_publicacao() {
        return Ano_publicacao;
    }

    public void setAno_publicacao(int Ano_publicacao) {
        this.Ano_publicacao = Ano_publicacao;
    }
    
     public String getISBN() {
        return ISBN;
    }

    public void setISBN(String ISBN) {
        this.ISBN = ISBN;
    }
    
}
